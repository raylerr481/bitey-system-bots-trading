# Bitey Scratch v1.0.0: guía de integración y diccionario de datos

Módulo para `Bitey_Ensemble_Scalper_MultiAsset_v1_8_1_4`. Se integra con **6 ediciones pequeñas**. No cambia tus 30 evaluadores, ni el ranking, ni el SL/TP adaptativo.

> No fue compilado ni validado. Compílalo en MetaEditor, prueba en el tester y luego en demo antes de confiar en él.

## 1. Instalación

1. Copia `Bitey_Scratch.mqh` en la **misma carpeta** que el `.mq4` (`MQL4\Experts`).
2. Haz estas 6 ediciones en el `.mq4`:

| # | Dónde | Añadir |
|---|---|---|
| 1 | Justo después de la línea `datetime g_lastRejectCsvTime[MAX_SYMBOLS];` (antes de `void BiteyCsvInitializeFiles()`) | `#include "Bitey_Scratch.mqh"` |
| 2 | En `OnInit()`, justo después de `BiteyCsvInitializeFiles();` | `ScratchInit();` |
| 3 | En `RunCycle()`, justo después de `ManageExits();` | `ScratchManage();` |
| 4 | En `Prefilter()`, después de la línea `if(InCooldown(sym)) {...}` | `if(!ScratchEntryGate(sym,why)) return(false);` |
| 5 | En `RunCycle()`, después del bloque `if(InpMinScore>0.0 && score<InpMinScore){...}` y antes de `int memN=0;` | ver abajo |
| 6 | En `OpenTrade()`, después de `GlobalVariableSet(GvKey("MAGIC",ticket),(double)InpMagic);` | `ScratchOnOpen(ticket,sym,cmd,score,regime,buyVotes,sellVotes,costR,spreadPrice,atr,filledEntry,sl,tp,lots,risk);` |

Edición 5:

```mql4
      {
         string scWhy="";
         if(!ScratchStrictOK(sym,cmd,score,g_tmpRegime,g_tmpBuyVotes,g_tmpSellVotes,scWhy))
         {
            if(RejectCsvDue(sym,"SCRATCH_"+scWhy))
               BiteyCsvLogAction(sym+"_"+IntegerToString((int)iTime(sym,InpSignalTF,1)),EA_VERSION,sym,
                  "SCRATCH_GATE","REJECT",0,(cmd==OP_BUY?"BUY":"SELL"),score,scWhy);
            RejectQuiet(sym,scWhy); continue;
         }
      }
```

## 2. Qué hace

- **Salida por neto:** cada ciclo calcula `neto = profit + swap − comisión(la mayor entre la posteada y la configurada) − costo extra`. Cierra cuando `neto ≥ objetivo + colchón` (con impuesto: `/(1−tax)`). El spread ya va dentro del profit.
- **Salida por tiempo:** a los `InpScratchMinutes` minutos cierra sin importar el resultado.
- **Fallo = neto ajustado ≤ 0:** el activo entra en **cuarentena** de `InpQuarantineHours × fallos seguidos` (tope `InpQuarantineMaxHours`). Al terminar, queda en **modo estricto** `InpStrictHours` o hasta que gane.
- **Modo estricto:** exige score mínimo, votos de modelos a favor, ADX, cost-R máximo y, opcionalmente, régimen de tendencia.
- Una victoria pone los fallos a 0. Si la ventana estricta pasa sin operar, los fallos se olvidan.
- Solo gestiona trades abiertos **por esta versión** (los que tienen marca de scratch). Los abiertos antes de instalarla se gestionan como siempre.

Recomendaciones para la primera prueba en demo:

- `InpScratchMinutes=20`, `InpScratchTargetUSD=0.10`, `InpScratchSafetyUSD=0.02`
- Deja `InpEnableAdaptiveExits` como está; casi no actuará en 20 min.
- Con trades de 20 min, valora `InpSignalTF=M5`. Hoy una señal por barra M15 limita cuántas oportunidades hay.

## 3. Archivos que genera (carpeta `MQL4\Files`)

| Archivo | Granularidad | Para qué |
|---|---|---|
| `Bitey_Scratch_Trades.csv` | 1 fila por trade cerrado | Tabla principal de análisis |
| `Bitey_Scratch_Events.csv` | 1 fila por evento | Línea de tiempo y trazabilidad |
| `Bitey_Scratch_Samples.csv` | 1 fila cada `InpScratchSampleSec` por trade abierto | Curva del neto en el tiempo |

Separador `;`. Estos CSV **nunca bloquean entradas** aunque fallen; el error sale en el Experts log como `SCRATCH_CSV_ERROR`.

### Identificadores (para unir tablas)

| Campo | Significado |
|---|---|
| `session_id` | Una ejecución del EA (`S` + hora local + 3 dígitos). Separa reinicios y runs del tester |
| `scratch_id` | `SIMBOLO_ticket_epochApertura`. Clave única de un trade; une Trades, Events y Samples |
| `decision_id` | `SIMBOLO_epochBarraDecisión`. Une con `Bitey_ActionLog`, `Bitey_TradeAssembly`, `Bitey_TradeAudit_*` y `Bitey_ClosedTrades_*` |
| `ticket`, `magic` | Orden de MT4 y magic del EA |
| `event_seq` | Contador de eventos dentro de la sesión |
| `cfg_id` | Resumen de la configuración, ej. `M20_T0.10_G0.12_Q2.0_ST42_SL1.50-2.25_TF15`. Sirve para comparar configuraciones |
| `ea_version`, `scratch_version` | Versiones del EA y del módulo |

### Columnas de `Bitey_Scratch_Trades.csv`

| Grupo | Columnas |
|---|---|
| Identidad | `timestamp, session_id, scratch_id, decision_id, ea_version, scratch_version, cfg_id, ticket, magic` |
| Activo y entorno | `symbol, asset_class` (FOREX/CRYPTO/EQUITY_TOKEN/OTHER), `account_mode` (DEMO/REAL, solo descriptor), `run_mode` (TESTER/TERMINAL), `direction` |
| Señal | `regime` (TREND/RANGE), `strict_mode` (1 = entró bajo modo estricto), `strikes_at_entry, score, buy_votes, sell_votes, dir_votes, adx_entry, atr_entry` |
| Costos y tamaño | `spread_entry_points, spread_cost_est_usd, cost_r_entry, lots, risk_money_usd` (= 1 R) |
| Tiempos y precios | `open_time, close_time, open_hour_server, open_dow, duration_sec, open_price, close_price, initial_sl, initial_tp` |
| Configuración | `cfg_minutes, cfg_target_usd, cfg_gate_usd` |
| Curva del trade | `first_neg_sec, first_pos_sec, first_target_sec` (**-1 = nunca ocurrió**), `time_neg_sec, time_pos_sec` (aprox.), `max_net_usd, min_net_usd, max_net_R, min_net_R` |
| Resultado | `gross_usd, commission_usd, swap_usd, net_usd` (real de MT4), `tax_usd, net_adj_usd` (tras extra e impuesto), `net_R, net_at_decision_usd, exec_slip_usd` (neto real − neto estimado al decidir), `close_attempts` |
| Clasificación | `close_reason, outcome_class, reached_target, was_negative` |
| Consecuencia | `strikes_after, quarantine_hours_applied, quarantine_until, strict_until` |

`outcome_class`:

- `WIN_TARGET`: cerró por objetivo con neto > 0.
- `WIN_TIMEOUT`: cerró por tiempo con neto > 0.
- `WIN_OTHER`: ganó por otra salida (TP, trailing, reversión…).
- `FLAT`: |neto| < 0.005.
- `LOSS_TARGET_SLIP`: cerró por objetivo pero el slippage dejó el neto ≤ 0.
- `LOSS_TIMEOUT`: cerró por tiempo en pérdida.
- `LOSS_SL`: lo cerró el SL del broker.
- `LOSS_OTHER`: pérdida por otra salida.

`close_reason` usa los textos del EA: `SCRATCH_TARGET`, `SCRATCH_TIMEOUT`, `BROKER_SL`, `BROKER_TP`, `PROFITABLE_CONFIRMED_REVERSAL`, `MEAN_TARGET`, `TIME_EXIT`, `ROLLOVER_FLAT`, `FRIDAY_FLAT`, etc.

### Eventos (`event_type`)

`SESSION_START`, `OPEN`, `FIRST_NEG`, `FIRST_POS`, `TARGET_HIT`, `CLOSE_SENT_TARGET`, `CLOSE_SENT_TIMEOUT`, `CLOSED`, `QUARANTINE_START`, `STRICT_CLEARED`.

Los rechazos de cuarentena y modo estricto quedan en `Bitey_ActionLog.csv` con `stage=SCRATCH_GATE` o el prefijo `PREFILTER_SCRATCH_QUARANTINE`.

## 4. Cómo medirlo después

Con `Bitey_Scratch_Trades.csv`, por activo, régimen y `cfg_id`:

- **Win rate neto** = filas con `net_adj_usd > 0` / total.
- **p_target** = media de `reached_target`.
- **Tiempo hasta el objetivo** = distribución de `first_target_sec` (solo ≠ -1).
- **Pérdida media** = media de `net_adj_usd` donde `net_adj_usd < 0`, separada por `LOSS_TIMEOUT` y `LOSS_SL`.
- **Win rate de equilibrio** = pérdida media / (pérdida media + ganancia media). Tu win rate real debe superarlo.
- **Expectativa por trade** = media de `net_adj_usd`, y también en R (`net_R`).
- **Fricción de cierre** = media de `exec_slip_usd` y `close_attempts`.
- **¿Funciona el modo estricto?** Compara `strict_mode=1` contra `0`.
- **¿Es buena la ventana de 20 min?** Con `Samples`, mira cuántos trades llegan al objetivo entre el minuto 10 y el 20. Si casi ninguno, acorta el tiempo.
- **Días positivos** = agrupa `net_adj_usd` por fecha de `close_time`.

Antes de subir riesgo o lote, exige una muestra grande (≥ 30 trades por activo y régimen).
