//+------------------------------------------------------------------+
//| Bitey_Scratch.mqh   SCRATCH-1.0.0   (MQL4, #property strict)      |
//| Modulo "scratch" para Bitey Ensemble Scalper v1.8.1.4             |
//|                                                                  |
//| 1. Cierra la operacion apenas el NETO estimado (profit + swap -   |
//|    comision - costos extra - impuesto) llega a InpScratchTargetUSD|
//|    (+ colchon de seguridad).                                      |
//| 2. Si pasan InpScratchMinutes sin llegar, cierra por tiempo.      |
//| 3. Si el trade termina en perdida: cuarentena del activo          |
//|    (progresiva) y, al salir, "modo estricto" para re-entrar.      |
//| 4. Registra TODO en 3 CSV para medir despues:                     |
//|      Bitey_Scratch_Trades.csv   1 fila por trade cerrado          |
//|      Bitey_Scratch_Events.csv   linea de tiempo de eventos        |
//|      Bitey_Scratch_Samples.csv  curva del neto cada N segundos    |
//|                                                                  |
//| Se incluye con:  #include "Bitey_Scratch.mqh"  (ver guia).        |
//| NO compilado ni validado: probar en el tester / demo primero.     |
//+------------------------------------------------------------------+
#ifndef BITEY_SCRATCH_MQH
#define BITEY_SCRATCH_MQH

#define SCRATCH_VERSION   "SCRATCH-1.0.0"
#define SC_FILE_TRADES    "Bitey_Scratch_Trades.csv"
#define SC_FILE_EVENTS    "Bitey_Scratch_Events.csv"
#define SC_FILE_SAMPLES   "Bitey_Scratch_Samples.csv"

input bool   InpScratchMode          = true;    // Scratch ON: cierra al neto objetivo o por tiempo
input int    InpScratchMinutes       = 20;      // Minutos maximos de vida del trade (0 = sin cierre por tiempo)
input double InpScratchTargetUSD     = 0.10;    // Neto objetivo (USD) despues de spread, comision, swap, extra e impuesto
input double InpScratchSafetyUSD     = 0.02;    // Colchon sobre el objetivo por slippage al cerrar
input double InpScratchTaxPct        = 0.0;     // Impuesto estimado sobre la ganancia (%); 0 = ninguno
input double InpScratchExtraCostUSD  = 0.0;     // Costo extra fijo por trade (USD) no incluido por el broker
input bool   InpScratchQuarantine    = true;    // Cuarentena + modo estricto tras un trade perdedor
input double InpQuarantineHours      = 2.0;     // Horas de cuarentena x numero de fallos seguidos
input double InpQuarantineMaxHours   = 12.0;    // Tope de la cuarentena progresiva
input double InpStrictHours          = 6.0;     // Horas de modo estricto tras salir de la cuarentena (o hasta ganar)
input double InpStrictMinScore       = 42.0;    // Estricto: score minimo (4 familias de acuerdo ~ 42+)
input int    InpStrictMinDirVotes    = 14;      // Estricto: modelos (de 30) a favor de la direccion
input double InpStrictMinADX         = 22.0;    // Estricto: ADX minimo
input double InpStrictMaxCostR       = 0.10;    // Estricto: cost-R maximo
input bool   InpStrictTrendOnly      = true;    // Estricto: solo regimen de tendencia
input bool   InpScratchLogDetail     = true;    // Escribe Events y Samples (Trades siempre se escribe)
input int    InpScratchSampleSec     = 30;      // Muestreo del neto cada N segundos (0 = off)

string   g_scSession  = "";
string   g_scCfg      = "";
int      g_scEventSeq = 0;
datetime g_scLastScan = 0;

//+------------------------------------------------------------------+
//| Helpers de claves GlobalVariable                                  |
//+------------------------------------------------------------------+
string ScKey(string tag,int ticket)  { return(GvKey("SC"+tag,ticket)); }
bool   ScHas(int ticket,string tag)  { return(GlobalVariableCheck(ScKey(tag,ticket))); }
double ScGet(int ticket,string tag,double def)
{
   string k=ScKey(tag,ticket);
   return(GlobalVariableCheck(k) ? GlobalVariableGet(k) : def);
}
void ScSet(int ticket,string tag,double v) { GlobalVariableSet(ScKey(tag,ticket),v); }

string ScSymKey(string tag,string sym) { return("BE"+IntegerToString(InpMagic)+"_SC"+tag+"_"+sym); }
double ScGetSym(string tag,string sym,double def)
{
   string k=ScSymKey(tag,sym);
   return(GlobalVariableCheck(k) ? GlobalVariableGet(k) : def);
}
void ScSetSym(string tag,string sym,double v) { GlobalVariableSet(ScSymKey(tag,sym),v); }

//+------------------------------------------------------------------+
//| Descriptores                                                      |
//+------------------------------------------------------------------+
string ScId(string sym,int ticket,datetime openTime)
{
   return(sym+"_"+IntegerToString(ticket)+"_"+IntegerToString((int)openTime));
}
string ScAssetClass(string sym)
{
   if(IsForex(sym)) return("FOREX");
   if(IsCrypto(sym)) return("CRYPTO");
   if(IsEquityToken(sym)) return("EQUITY_TOKEN");
   return("OTHER");
}
string ScRegimeName(int regime)
{
   if(regime==1) return("TREND");
   if(regime==2) return("RANGE");
   return("NA");
}
string ScOutcomeClass(string why,double net)
{
   if(MathAbs(net)<0.005) return("FLAT");
   if(net>0.0)
   {
      if(why=="SCRATCH_TARGET")  return("WIN_TARGET");
      if(why=="SCRATCH_TIMEOUT") return("WIN_TIMEOUT");
      return("WIN_OTHER");
   }
   if(why=="SCRATCH_TARGET")  return("LOSS_TARGET_SLIP");
   if(why=="SCRATCH_TIMEOUT") return("LOSS_TIMEOUT");
   if(why=="BROKER_SL")       return("LOSS_SL");
   return("LOSS_OTHER");
}
// Neto minimo estimado para disparar el cierre (objetivo + colchon, ajustado por impuesto)
double ScTargetGate()
{
   double t=InpScratchTargetUSD+InpScratchSafetyUSD;
   double tx=MathMin(MathMax(InpScratchTaxPct,0.0),90.0)/100.0;
   if(tx>0.0) t=t/(1.0-tx);
   return(t);
}
// Neto estimado de la orden SELECCIONADA: profit + swap - comision (la mayor entre la posteada y la configurada) - extra
double ScNetEst()
{
   double lots=OrderLots();
   string sym=OrderSymbol();
   double comm=MathMax(MathAbs(OrderCommission()),CommissionPerLot(sym)*lots);
   return(OrderProfit()+OrderSwap()-comm-InpScratchExtraCostUSD);
}
// Fallos seguidos vigentes: si la ventana estricta ya termino antes de 'at', se consideran olvidados
int ScStrikes(string sym,datetime at)
{
   int st=(int)ScGetSym("STRIKE",sym,0.0);
   if(st<=0) return(0);
   if(ScGetSym("SUNTIL",sym,0.0)>(double)at) return(st);
   return(0);
}
bool ScIsStrict(string sym)
{
   return(ScGetSym("SUNTIL",sym,0.0)>(double)TimeCurrent());
}

//+------------------------------------------------------------------+
//| CSV: columnas construidas en un solo lugar (header y fila alineados) |
//+------------------------------------------------------------------+
void ScCol(string &hdr,string &row,const string name,string val)
{
   StringReplace(val,";",",");
   StringReplace(val,"\r"," ");
   StringReplace(val,"\n"," ");
   if(StringLen(hdr)>0) { hdr+=";"; row+=";"; }
   hdr+=name;
   row+=val;
}
bool ScWriteRow(const string fileName,const string hdr,const string row)
{
   bool keep=g_csvFailed;                 // los CSV de medicion nunca bloquean entradas
   int h=BiteyCsvOpenAppend(fileName,hdr);
   g_csvFailed=keep;
   if(h==INVALID_HANDLE) { Print("SCRATCH_CSV_ERROR | file=",fileName," err=",GetLastError()); return(false); }
   FileWriteString(h,row+"\r\n");
   BiteyCsvClose(h);
   return(true);
}
void ScEvent(int ticket,string sym,string scratchId,string evType,int elapsed,double net,string detail)
{
   if(!InpScratchLogDetail) return;
   g_scEventSeq++;
   string hdr="", row="";
   ScCol(hdr,row,"timestamp",BiteyCsvStamp());
   ScCol(hdr,row,"session_id",g_scSession);
   ScCol(hdr,row,"event_seq",IntegerToString(g_scEventSeq));
   ScCol(hdr,row,"scratch_id",scratchId);
   ScCol(hdr,row,"ticket",IntegerToString(ticket));
   ScCol(hdr,row,"symbol",sym);
   ScCol(hdr,row,"event_type",evType);
   ScCol(hdr,row,"elapsed_sec",IntegerToString(elapsed));
   ScCol(hdr,row,"net_est_usd",DoubleToString(net,4));
   ScCol(hdr,row,"gate_usd",DoubleToString(ScTargetGate(),4));
   ScCol(hdr,row,"ea_version",EA_VERSION);
   ScCol(hdr,row,"cfg_id",g_scCfg);
   ScCol(hdr,row,"detail",detail);
   ScWriteRow(SC_FILE_EVENTS,hdr,row);
}
void ScSample(int ticket,string sym,string scratchId,int elapsed,double net,double risk0)
{
   double bid=MarketInfo(sym,MODE_BID), ask=MarketInfo(sym,MODE_ASK), pt=MarketInfo(sym,MODE_POINT);
   int digs=(int)MarketInfo(sym,MODE_DIGITS);
   double nmax=ScGet(ticket,"NMAX",net), nmin=ScGet(ticket,"NMIN",net);
   string hdr="", row="";
   ScCol(hdr,row,"timestamp",BiteyCsvStamp());
   ScCol(hdr,row,"session_id",g_scSession);
   ScCol(hdr,row,"scratch_id",scratchId);
   ScCol(hdr,row,"ticket",IntegerToString(ticket));
   ScCol(hdr,row,"symbol",sym);
   ScCol(hdr,row,"elapsed_sec",IntegerToString(elapsed));
   ScCol(hdr,row,"net_est_usd",DoubleToString(net,4));
   ScCol(hdr,row,"net_R",DoubleToString(risk0>0.0 ? net/risk0 : 0.0,4));
   ScCol(hdr,row,"bid",DoubleToString(bid,digs));
   ScCol(hdr,row,"ask",DoubleToString(ask,digs));
   ScCol(hdr,row,"spread_points",DoubleToString(pt>0.0 ? (ask-bid)/pt : 0.0,1));
   ScCol(hdr,row,"max_net_usd",DoubleToString(nmax,4));
   ScCol(hdr,row,"min_net_usd",DoubleToString(nmin,4));
   ScWriteRow(SC_FILE_SAMPLES,hdr,row);
}

//+------------------------------------------------------------------+
//| Inicializacion                                                    |
//+------------------------------------------------------------------+
void ScratchInit()
{
   g_scSession="S"+IntegerToString((int)TimeLocal())+IntegerToString((int)(GetTickCount()%1000));
   g_scCfg="M"+IntegerToString(InpScratchMinutes)+"_T"+DoubleToString(InpScratchTargetUSD,2)+
           "_G"+DoubleToString(ScTargetGate(),2)+"_Q"+DoubleToString(InpQuarantineHours,1)+
           "_ST"+DoubleToString(InpStrictMinScore,0)+"_SL"+DoubleToString(InpStopATR,2)+
           "-"+DoubleToString(InpStopATRMax,2)+"_TF"+IntegerToString((int)InpSignalTF);
   g_scEventSeq=0;
   g_scLastScan=0;
   Print("SCRATCH_INIT | ",SCRATCH_VERSION," session=",g_scSession," cfg=",g_scCfg," mode=",(InpScratchMode?"ON":"OFF"));
   ScEvent(0,"ALL","","SESSION_START",0,0.0,
           "mode="+(InpScratchMode?"ON":"OFF")+";minutes="+IntegerToString(InpScratchMinutes)+
           ";targetUSD="+DoubleToString(InpScratchTargetUSD,2)+";safetyUSD="+DoubleToString(InpScratchSafetyUSD,2)+
           ";taxPct="+DoubleToString(InpScratchTaxPct,1)+";quarantine="+(InpScratchQuarantine?"ON":"OFF")+
           ";run="+(IsTesting()?"TESTER":"TERMINAL"));
}

//+------------------------------------------------------------------+
//| Puertas de entrada                                                |
//+------------------------------------------------------------------+
// Prefilter: el activo esta en cuarentena?
bool ScratchEntryGate(string sym,string &why)
{
   why="";
   if(!InpScratchMode || !InpScratchQuarantine) return(true);
   if(ScGetSym("QUNTIL",sym,0.0)>(double)TimeCurrent()) { why="SCRATCH_QUARANTINE"; return(false); }
   return(true);
}
// Tras Analyze: si el activo esta en modo estricto, exige mas
bool ScratchStrictOK(string sym,int cmd,double score,int regime,int buyVotes,int sellVotes,string &why)
{
   why="";
   if(!InpScratchMode || !InpScratchQuarantine) return(true);
   if(!ScIsStrict(sym)) return(true);
   int dirVotes=(cmd==OP_BUY ? buyVotes : sellVotes);
   if(score<InpStrictMinScore) why="STRICT_SCORE";
   else if(dirVotes<InpStrictMinDirVotes) why="STRICT_DIR_VOTES";
   else if(InpStrictTrendOnly && regime!=1) why="STRICT_NOT_TREND";
   else
   {
      double adx=iADX(sym,InpSignalTF,14,PRICE_CLOSE,MODE_MAIN,1);
      if(adx<InpStrictMinADX) why="STRICT_ADX";
      else if(CandCostR(sym)>InpStrictMaxCostR) why="STRICT_COST_R";
   }
   return(why=="");
}

//+------------------------------------------------------------------+
//| Apertura: guarda el contexto de entrada y registra el evento OPEN |
//+------------------------------------------------------------------+
void ScratchOnOpen(int ticket,string sym,int cmd,double score,int regime,int buyVotes,int sellVotes,
                   double costR,double spreadPrice,double atr,double entry,double sl,double tp,
                   double lots,double riskMoney)
{
   if(!InpScratchMode) return;
   datetime ot=TimeCurrent();
   if(OrderSelect(ticket,SELECT_BY_TICKET)) ot=OrderOpenTime();
   datetime now=TimeCurrent();
   bool strict=ScIsStrict(sym);
   int strikes=ScStrikes(sym,now);
   double adx=iADX(sym,InpSignalTF,14,PRICE_CLOSE,MODE_MAIN,1);
   double pt=MarketInfo(sym,MODE_POINT);
   double sprPts=(pt>0.0 ? spreadPrice/pt : 0.0);
   double scost=0.0, ccomm=0.0;
   EstCostPerLot(sym,scost,ccomm);
   ScSet(ticket,"ON",1.0);
   ScSet(ticket,"LAST",(double)now);
   ScSet(ticket,"SCORE",score);
   ScSet(ticket,"REG",(double)regime);
   ScSet(ticket,"STRICT",(strict?1.0:0.0));
   ScSet(ticket,"STRK",(double)strikes);
   ScSet(ticket,"ADX",adx);
   ScSet(ticket,"ATR",atr);
   ScSet(ticket,"SPRPTS",sprPts);
   ScSet(ticket,"SPCOST",scost*lots);
   ScSet(ticket,"COSTR",costR);
   ScSet(ticket,"RISK",riskMoney);
   ScSet(ticket,"BV",(double)buyVotes);
   ScSet(ticket,"SV",(double)sellVotes);
   ScSet(ticket,"ISL",sl);
   ScSet(ticket,"ITP",tp);
   ScEvent(ticket,sym,ScId(sym,ticket,ot),"OPEN",0,0.0,
           "dir="+(cmd==OP_BUY?"BUY":"SELL")+";regime="+ScRegimeName(regime)+";score="+DoubleToString(score,1)+
           ";strict="+(strict?"1":"0")+";strikes="+IntegerToString(strikes)+
           ";dirVotes="+IntegerToString(cmd==OP_BUY?buyVotes:sellVotes)+";adx="+DoubleToString(adx,1)+
           ";costR="+DoubleToString(costR,3)+";lots="+DoubleToString(lots,2)+
           ";riskUSD="+DoubleToString(riskMoney,2)+";spreadPts="+DoubleToString(sprPts,1)+
           ";spreadCostUSD="+DoubleToString(scost*lots,3));
}

//+------------------------------------------------------------------+
//| Gestion de trades abiertos (llamar cada ciclo, tras ManageExits)  |
//+------------------------------------------------------------------+
void ScratchManage()
{
   ScratchScanClosed();
   if(!InpScratchMode) return;
   datetime now=TimeCurrent();
   double gate=ScTargetGate();
   for(int pos=OrdersTotal()-1;pos>=0;pos--)
   {
      if(!OrderSelect(pos,SELECT_BY_POS,MODE_TRADES)) continue;
      if(OrderMagicNumber()!=InpMagic) continue;
      int type=OrderType();
      if(type!=OP_BUY && type!=OP_SELL) continue;
      int ticket=OrderTicket();
      if(!ScHas(ticket,"ON")) continue;                 // trade abierto sin scratch: no se toca
      string sym=OrderSymbol();
      datetime ot=OrderOpenTime();
      int elapsed=(int)(now-ot);
      if(elapsed<0) elapsed=0;
      double netE=ScNetEst();
      string sid=ScId(sym,ticket,ot);
      double risk0=ScGet(ticket,"RISK",0.0);

      // --- seguimiento ---
      double lastT=ScGet(ticket,"LAST",(double)ot);
      int dt=(int)(now-(datetime)lastT);
      if(dt<0) dt=0;
      if(dt>10) dt=10;                                  // aproximado si el terminal estuvo detenido
      ScSet(ticket,"LAST",(double)now);
      if(netE<0.0) ScSet(ticket,"TNEG",ScGet(ticket,"TNEG",0.0)+dt);
      else         ScSet(ticket,"TPOS",ScGet(ticket,"TPOS",0.0)+dt);
      if(!ScHas(ticket,"NMAX") || netE>ScGet(ticket,"NMAX",netE)) ScSet(ticket,"NMAX",netE);
      if(!ScHas(ticket,"NMIN") || netE<ScGet(ticket,"NMIN",netE)) ScSet(ticket,"NMIN",netE);
      if(netE<0.0 && ScGet(ticket,"TFNEG",-1.0)<0.0)
      {
         ScSet(ticket,"TFNEG",(double)elapsed);
         ScEvent(ticket,sym,sid,"FIRST_NEG",elapsed,netE,"");
      }
      if(netE>=0.0 && ScGet(ticket,"TFPOS",-1.0)<0.0)
      {
         ScSet(ticket,"TFPOS",(double)elapsed);
         ScEvent(ticket,sym,sid,"FIRST_POS",elapsed,netE,"");
      }
      if(netE>=gate && ScGet(ticket,"TFTGT",-1.0)<0.0)
      {
         ScSet(ticket,"TFTGT",(double)elapsed);
         ScEvent(ticket,sym,sid,"TARGET_HIT",elapsed,netE,"");
      }
      if(InpScratchLogDetail && InpScratchSampleSec>0)
      {
         double ls=ScGet(ticket,"LSAMP",0.0);
         if(ls<=0.0 || (now-(datetime)ls)>=InpScratchSampleSec)
         {
            ScSet(ticket,"LSAMP",(double)now);
            ScSample(ticket,sym,sid,elapsed,netE,risk0);
         }
      }

      // --- decisiones de cierre ---
      if(netE>=gate)
      {
         ScSet(ticket,"NDEC",netE);
         double att=ScGet(ticket,"CATT",0.0)+1.0;
         ScSet(ticket,"CATT",att);
         if(att<1.5) ScEvent(ticket,sym,sid,"CLOSE_SENT_TARGET",elapsed,netE,"");
         CloseTicket(ticket,"SCRATCH_TARGET");
         continue;
      }
      if(InpScratchMinutes>0 && elapsed>=InpScratchMinutes*60)
      {
         ScSet(ticket,"NDEC",netE);
         double att2=ScGet(ticket,"CATT",0.0)+1.0;
         ScSet(ticket,"CATT",att2);
         if(att2<1.5) ScEvent(ticket,sym,sid,"CLOSE_SENT_TIMEOUT",elapsed,netE,"");
         CloseTicket(ticket,"SCRATCH_TIMEOUT");
         continue;
      }
   }
}

//+------------------------------------------------------------------+
//| Detecta trades scratch ya cerrados y los procesa                  |
//+------------------------------------------------------------------+
void ScratchScanClosed()
{
   datetime now=TimeCurrent();
   if(g_scLastScan!=0 && now-g_scLastScan<3) return;
   g_scLastScan=now;
   int total=OrdersHistoryTotal();
   int seen=0;
   for(int i=total-1;i>=0 && seen<200;i--)
   {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_HISTORY)) continue;
      seen++;
      if(OrderMagicNumber()!=InpMagic) continue;
      int type=OrderType();
      if(type!=OP_BUY && type!=OP_SELL) continue;
      if(OrderCloseTime()<=0) continue;
      int ticket=OrderTicket();
      if(!ScHas(ticket,"ON") || ScHas(ticket,"DONE")) continue;
      ScProcessClosed(ticket);
   }
}

void ScClearTicket(int ticket)
{
   string tags[27]={"ON","LAST","TNEG","TPOS","NMAX","NMIN","TFNEG","TFPOS","TFTGT","LSAMP",
                    "CATT","NDEC","SCORE","REG","STRICT","STRK","ADX","ATR","SPRPTS","SPCOST",
                    "COSTR","RISK","BV","SV","ISL","ITP","TRY"};
   for(int i=0;i<27;i++) GlobalVariableDel(ScKey(tags[i],ticket));
}

void ScProcessClosed(int ticket)
{
   if(!OrderSelect(ticket,SELECT_BY_TICKET)) return;
   if(OrderCloseTime()<=0) return;
   string sym=OrderSymbol();
   int type=OrderType();
   double lots=OrderLots();
   datetime ot=OrderOpenTime(), ct=OrderCloseTime();
   double op=OrderOpenPrice(), cp=OrderClosePrice();
   double gross=OrderProfit(), comm=OrderCommission(), swp=OrderSwap();
   string cmt=OrderComment();
   int digs=(int)MarketInfo(sym,MODE_DIGITS);
   double net=gross+comm+swp;
   double tax=(net>0.0 ? net*MathMax(0.0,InpScratchTaxPct)/100.0 : 0.0);
   double netAdj=net-InpScratchExtraCostUSD-tax;
   string why=LookupCloseReason(ticket,cmt);
   string cls=ScOutcomeClass(why,net);
   string sid=ScId(sym,ticket,ot);
   string dir=(type==OP_BUY?"BUY":"SELL");

   // contexto guardado en la apertura
   double risk0=ScGet(ticket,"RISK",0.0);
   double nmax=ScGet(ticket,"NMAX",0.0), nmin=ScGet(ticket,"NMIN",0.0);
   double tfneg=ScGet(ticket,"TFNEG",-1.0), tfpos=ScGet(ticket,"TFPOS",-1.0), tftgt=ScGet(ticket,"TFTGT",-1.0);
   double ndec=ScGet(ticket,"NDEC",0.0);
   int    regime=(int)ScGet(ticket,"REG",0.0);
   int    bv=(int)ScGet(ticket,"BV",0.0), sv=(int)ScGet(ticket,"SV",0.0);
   int    dirVotes=(type==OP_BUY?bv:sv);
   int    strictAtEntry=(int)ScGet(ticket,"STRICT",0.0);
   int    strikesAtEntry=(int)ScGet(ticket,"STRK",0.0);
   double decisionBar=(GlobalVariableCheck(GvKey("DID",ticket)) ? GlobalVariableGet(GvKey("DID",ticket)) : 0.0);
   string decisionId=(decisionBar>0.0 ? sym+"_"+IntegerToString((int)decisionBar) : "ticket_"+IntegerToString(ticket));
   int dur=(int)(ct-ot);

   // cuarentena / modo estricto (se confirma despues de escribir la fila)
   bool win=(netAdj>0.0);
   int strikesBefore=ScStrikes(sym,ct);
   int strikesAfter=strikesBefore;
   double qHours=0.0;
   datetime qUntil=0, sUntil=0;
   if(InpScratchQuarantine)
   {
      if(win) strikesAfter=0;
      else
      {
         strikesAfter=strikesBefore+1;
         qHours=MathMin(MathMax(InpQuarantineMaxHours,0.0),MathMax(0.0,InpQuarantineHours)*strikesAfter);
         qUntil=(datetime)((double)ct+qHours*3600.0);
         sUntil=(datetime)((double)qUntil+MathMax(0.0,InpStrictHours)*3600.0);
      }
   }

   string hdr="", row="";
   // --- identificadores ---
   ScCol(hdr,row,"timestamp",BiteyCsvStamp());
   ScCol(hdr,row,"session_id",g_scSession);
   ScCol(hdr,row,"scratch_id",sid);
   ScCol(hdr,row,"decision_id",decisionId);
   ScCol(hdr,row,"ea_version",EA_VERSION);
   ScCol(hdr,row,"scratch_version",SCRATCH_VERSION);
   ScCol(hdr,row,"cfg_id",g_scCfg);
   ScCol(hdr,row,"ticket",IntegerToString(ticket));
   ScCol(hdr,row,"magic",IntegerToString(InpMagic));
   // --- descriptores del activo y del entorno ---
   ScCol(hdr,row,"symbol",sym);
   ScCol(hdr,row,"asset_class",ScAssetClass(sym));
   ScCol(hdr,row,"account_mode",(IsDemo()?"DEMO":"REAL"));          // descriptor, nunca una puerta
   ScCol(hdr,row,"run_mode",(IsTesting()?"TESTER":"TERMINAL"));
   ScCol(hdr,row,"direction",dir);
   // --- contexto de la senal ---
   ScCol(hdr,row,"regime",ScRegimeName(regime));
   ScCol(hdr,row,"strict_mode",IntegerToString(strictAtEntry));
   ScCol(hdr,row,"strikes_at_entry",IntegerToString(strikesAtEntry));
   ScCol(hdr,row,"score",DoubleToString(ScGet(ticket,"SCORE",0.0),2));
   ScCol(hdr,row,"buy_votes",IntegerToString(bv));
   ScCol(hdr,row,"sell_votes",IntegerToString(sv));
   ScCol(hdr,row,"dir_votes",IntegerToString(dirVotes));
   ScCol(hdr,row,"adx_entry",DoubleToString(ScGet(ticket,"ADX",0.0),2));
   ScCol(hdr,row,"atr_entry",DoubleToString(ScGet(ticket,"ATR",0.0),digs));
   // --- costos y tamano ---
   ScCol(hdr,row,"spread_entry_points",DoubleToString(ScGet(ticket,"SPRPTS",0.0),1));
   ScCol(hdr,row,"spread_cost_est_usd",DoubleToString(ScGet(ticket,"SPCOST",0.0),4));
   ScCol(hdr,row,"cost_r_entry",DoubleToString(ScGet(ticket,"COSTR",0.0),4));
   ScCol(hdr,row,"lots",DoubleToString(lots,2));
   ScCol(hdr,row,"risk_money_usd",DoubleToString(risk0,4));
   // --- tiempos y precios ---
   ScCol(hdr,row,"open_time",TimeToString(ot,TIME_DATE|TIME_SECONDS));
   ScCol(hdr,row,"close_time",TimeToString(ct,TIME_DATE|TIME_SECONDS));
   ScCol(hdr,row,"open_hour_server",IntegerToString(TimeHour(ot)));
   ScCol(hdr,row,"open_dow",IntegerToString(TimeDayOfWeek(ot)));
   ScCol(hdr,row,"duration_sec",IntegerToString(dur));
   ScCol(hdr,row,"open_price",DoubleToString(op,digs));
   ScCol(hdr,row,"close_price",DoubleToString(cp,digs));
   ScCol(hdr,row,"initial_sl",DoubleToString(ScGet(ticket,"ISL",0.0),digs));
   ScCol(hdr,row,"initial_tp",DoubleToString(ScGet(ticket,"ITP",0.0),digs));
   // --- configuracion scratch ---
   ScCol(hdr,row,"cfg_minutes",IntegerToString(InpScratchMinutes));
   ScCol(hdr,row,"cfg_target_usd",DoubleToString(InpScratchTargetUSD,4));
   ScCol(hdr,row,"cfg_gate_usd",DoubleToString(ScTargetGate(),4));
   // --- curva del trade (-1 = nunca ocurrio) ---
   ScCol(hdr,row,"first_neg_sec",IntegerToString((int)tfneg));
   ScCol(hdr,row,"first_pos_sec",IntegerToString((int)tfpos));
   ScCol(hdr,row,"first_target_sec",IntegerToString((int)tftgt));
   ScCol(hdr,row,"time_neg_sec",IntegerToString((int)ScGet(ticket,"TNEG",0.0)));
   ScCol(hdr,row,"time_pos_sec",IntegerToString((int)ScGet(ticket,"TPOS",0.0)));
   ScCol(hdr,row,"max_net_usd",DoubleToString(nmax,4));
   ScCol(hdr,row,"min_net_usd",DoubleToString(nmin,4));
   ScCol(hdr,row,"max_net_R",DoubleToString(risk0>0.0 ? nmax/risk0 : 0.0,4));
   ScCol(hdr,row,"min_net_R",DoubleToString(risk0>0.0 ? nmin/risk0 : 0.0,4));
   // --- resultado ---
   ScCol(hdr,row,"gross_usd",DoubleToString(gross,4));
   ScCol(hdr,row,"commission_usd",DoubleToString(comm,4));
   ScCol(hdr,row,"swap_usd",DoubleToString(swp,4));
   ScCol(hdr,row,"net_usd",DoubleToString(net,4));
   ScCol(hdr,row,"tax_usd",DoubleToString(tax,4));
   ScCol(hdr,row,"net_adj_usd",DoubleToString(netAdj,4));
   ScCol(hdr,row,"net_R",DoubleToString(risk0>0.0 ? net/risk0 : 0.0,4));
   ScCol(hdr,row,"net_at_decision_usd",DoubleToString(ndec,4));
   ScCol(hdr,row,"exec_slip_usd",DoubleToString(ndec!=0.0 ? net-ndec : 0.0,4));
   ScCol(hdr,row,"close_attempts",IntegerToString((int)ScGet(ticket,"CATT",0.0)));
   ScCol(hdr,row,"close_reason",why);
   ScCol(hdr,row,"outcome_class",cls);
   ScCol(hdr,row,"reached_target",(tftgt>=0.0?"1":"0"));
   ScCol(hdr,row,"was_negative",((tfneg>=0.0 || nmin<0.0)?"1":"0"));
   // --- consecuencia ---
   ScCol(hdr,row,"strikes_after",IntegerToString(strikesAfter));
   ScCol(hdr,row,"quarantine_hours_applied",DoubleToString(qHours,2));
   ScCol(hdr,row,"quarantine_until",(qUntil>0 ? TimeToString(qUntil,TIME_DATE|TIME_SECONDS) : ""));
   ScCol(hdr,row,"strict_until",(sUntil>0 ? TimeToString(sUntil,TIME_DATE|TIME_SECONDS) : ""));

   int tries=(int)ScGet(ticket,"TRY",0.0)+1;
   ScSet(ticket,"TRY",(double)tries);
   bool ok=ScWriteRow(SC_FILE_TRADES,hdr,row);
   if(!ok && tries<3) return;                           // reintenta en el siguiente barrido

   // confirmacion: estado por activo
   if(InpScratchQuarantine)
   {
      if(win)
      {
         ScSetSym("STRIKE",sym,0.0);
         ScSetSym("QUNTIL",sym,0.0);
         ScSetSym("SUNTIL",sym,0.0);
         if(strikesBefore>0) ScEvent(ticket,sym,sid,"STRICT_CLEARED",dur,net,"win_after_strikes="+IntegerToString(strikesBefore));
      }
      else
      {
         ScSetSym("STRIKE",sym,(double)strikesAfter);
         ScSetSym("QUNTIL",sym,(double)qUntil);
         ScSetSym("SUNTIL",sym,(double)sUntil);
         ScEvent(ticket,sym,sid,"QUARANTINE_START",dur,net,
                 "strikes="+IntegerToString(strikesAfter)+";hours="+DoubleToString(qHours,2)+
                 ";until="+TimeToString(qUntil,TIME_DATE|TIME_SECONDS)+
                 ";strictUntil="+TimeToString(sUntil,TIME_DATE|TIME_SECONDS));
      }
   }
   ScEvent(ticket,sym,sid,"CLOSED",dur,net,"class="+cls+";reason="+why+";netAdj="+DoubleToString(netAdj,4));
   ScSet(ticket,"DONE",1.0);                            // marca final (ScClearTicket no la borra)
   ScClearTicket(ticket);
}

#endif
//+------------------------------------------------------------------+
